﻿using System;

namespace matchingGame
{
    internal class MySqlCommand
    {
        private MySqlConnection connection;
        private string query;

        public MySqlCommand(string query, MySqlConnection connection)
        {
            this.query = query;
            this.connection = connection;
        }

        internal void ExecuteNonQuery()
        {
            throw new NotImplementedException();
        }

        internal MySqlDataReader ExecuteReader()
        {
            throw new NotImplementedException();
        }
    }
}