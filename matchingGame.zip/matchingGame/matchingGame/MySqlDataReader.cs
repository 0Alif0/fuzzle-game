﻿namespace matchingGame
{
    internal class MySqlDataReader
    {
        public bool HasRows { get; internal set; }
    }
}