﻿using System;
using MySql.Data.MySqlClient;

namespace matchingGame
{
    internal class MySqlConnection
    {
        private string connectionstring;

        public MySqlConnection(string connectionstring)
        {
            this.connectionstring = connectionstring;
        }

        internal void Close()
        {
            throw new NotImplementedException();
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}